''' Deel 3: Koppelingstabel tussen de huisartsen en de praktijken. Deze tabel wordt 
gegenereerd aan de hand van 3 geleverde datasets: de vektis_agb_zorgverlener, Praktijk
en Koppeling (hierin wordt een koppeling gemaakt tussen de zorgverlener en praktijk op
basis van unieke nummers)'''


import csv  
import sqlite3

'''Alle benodigde arrays worden aangemaakt'''
praktijk = []
haData = []
prNr = []
prNa1 = []
prNa2 = []
pr = []
prSort = []
koppel = []
kopHa = []
kopPr = []
kopHaPr = []
koppelSort = []

'''Leest het bijgevoegde csv bestand in en bekijkt welke rijen als zorgverlenersoort '01' hebben.
   Dat geeft aan dat de rij gegevens over een huisarts bevat.
   De functie slaat deze gevonden rijen in een nieuwe lijst op.'''
   
def gegevensHuisartsZoeken():
    with open('vektis_agb_zorgverlener.csv', encoding='utf-8', errors='ignore') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for row in reader:
            if row[2] == '01':
                haData.append(row)
        print(haData)


'''Maak van voorletters, tussenvoegsel(s) en achternaam één list.'''
def listMakenNaam():
    for item in haData:
        if item[6] != '(null)':
            item[4] = item[5] + ' ' + item[6] + ' ' + item[4]
            item.remove(item[5])
            item.remove(item[6])
        else:
            item[4] = item[5] + ' ' + item[4]
            item.remove(item[5])
            item.remove(item[6])


'''Leest het bijgevoegde csv bestand en bekijkt welke rijen als zorgverlenersoort '01' hebben.
   Dat geeft aan dat de rij gegevens over een huisartsenpraktijk bevat.
   De functie slaat deze gevonden rijen in een nieuwe lijst op.'''
   
def praktijkZoeken():
    with open('Praktijk.csv', encoding='utf-8', errors='ignore') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for row in reader:
            if row[2] == '01':
                praktijk.append(row)
        
''' Er worden drie nieuwe lijsten gevuld met respectievelijk praktijknummer en
naam van de praktijk, die in de lijst met praktijkgegevens te vinden zijn. De naam 
van de praktijk was in de aangeleverde datasets soms gesplitst. Vandaar dat er twee
delen zijn waaruit de naam is opgebouwd.  '''
def praktijkVullen():
    for item in praktijk:
        prNr.append(item[3])
        prNa1.append(item[4])
        prNa2.append(item[5])


'''
.. function:: prSamenvoegen(lst1, lst2, lst3)
   Maakt van de drie lijsten één lijst met praktijknummer en naam.
   :param lst1: lijst met nummer van praktijk (niet telefoonnummer, maar het unieke praktijknummer!) 
   :param lst2: lijst met eerste deel van naam
   :param lst3: lijst met tweede deel van naam
'''
def prSamenvoegen(lst1, lst2, lst3):
    for item in lst1:
        pr.append(item)
    for item in lst2:
        pr.append(item)
    for item in lst3:
        pr.append(item)
        
'''
.. function:: praktijkSort(lst)
   Sorteert de lijst met samengevoegde praktijkgegevens zodat er een volledige lijst met
   overzichtelijke gegevens gemaakt kan worden.
   :param lst: lijst met praktijkgegevens
'''
def praktijkSort(lst):
    for i in range(len(praktijk)):
        prSort.append(lst[i:len(pr)+i:len(praktijk)])
        


'''De eerste en tweede kolom worden samengevoegd. Hierdoor wordt de naam van een praktijk,
die in de originele datasets soms in twee kolommen stond, samengevoegd. Mocht bij een 
naam in de originele dataset geen tweede deel van een naam worden genoemd, dan wordt
er niets aan de naam verandert. Als het tweede deel bij het eerste deel is gevoegd, of
mocht er geen tweede deel zijn, dan wordt de tweede kolom gewist zodat er nog maar 
1 kolom is met de volledige naam'''

def kolomSamenvoegen():
    for item in prSort:
        if item[2] != '(null)':
            item[1] = item[1] + ' ' + item[2]
        item.remove(item[2])



'''Leest het bijgevoegde csv bestand en bekijkt welke rijen als zorgverlenersoort '01' hebben.
   Dat geeft aan dat de rij gegevens over een huisarts bevat.
   De functie slaat deze gevonden rijen in een nieuwe lijst op.'''
def bestandInlezen():  
    with open('Koppeling.csv', encoding='utf-8', errors='ignore') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for row in reader:
            if row[2] == '01':
                koppel.append(row)
       

''' Voor elke rij in de koppeltabel worden de zorgverlenernummers en praktijknummers gehaald. 
    Deze nummers worden in nieuwe lijsten geplaatst: één lijst voor de huisartsnummers
    en één lijst voor de praktijknummers.'''
def nummersSplitsen():
    for item in koppel:
        kopHa.append(item[3])
        kopPr.append(item[4])
    

'''
.. function:: haEnPr(lst1, lst2)
   De koppeltabel wordt gemaakt door beide nummertypes in één koppellijst te zetten.
   :param lst1: lijst met zorgverlenernummers.
   :param lst2: lijst met praktijknummers
'''
def haEnPr(lst1, lst2):
    for item in lst1:
        kopHaPr.append(item)
    for item in lst2:
        kopHaPr.append(item)

'''
.. function:: kopSort(lst)
   Sorteert de lijst met samengevoegde nummers zodat de correcte huisartsennummers gekoppeld
   worden aan de juiste praktijknummers.
   :param lst: lijst met zorgverlenernummers en praktijknummers
'''
def kopSort(lst):
    for i in range(len(kopHa)):
        koppelSort.append(lst[i:len(kopHaPr)+i:len(kopHa)])
        
'''
.. function:: koppeling(lst1, lst2, lst3)
   Vervang in de lijst met koppelingen de nummers van de huisartsen en
   praktijken door de namen van de huisartsen en praktijken.
   :param lst1: lijst met gesorteerde nummers (zowel van de huisarts als de praktijk)
   :param lst2: lijst met gesorteerde praktijkgegevens (hieruit wordt de praktijknaam verkregen)
   :param lst3: lijst met huisartsengegevens (hieruit wordt de naam van de huisarts verkregen)
'''
def koppeling(lst1, lst2, lst3):
    for item in lst1:
        for obj in lst3:
            if item[0] == obj[2]:
                item[0] = obj[3]
        for ding in lst2:
            if item[1] == ding[0]:
                item[1] = ding[1]
        


'''De gevonden gegevens moeten worden opgeslagen in een database
   Deze method schrijft de gegenereerde data weg naar de specialismendatabase
   in een tabel genaamd Huisartsen.'''

def databaseInvullen():
    db = sqlite3.connect('specialismen_db.sqlite')
    
    cursor = db.cursor()
    cursor.execute('''
       CREATE TABLE IF NOT EXISTS Huisartsen(huisarts TEXT, praktijk TEXT)
    ''')
    
    for lst in koppelSort:
       cursor.execute('''INSERT INTO Huisartsen(huisarts, praktijk)
                    VALUES(?,?)''', (lst[0], lst[1]))
    
    db.commit()
    cursor.close()

'''De main method waarin alle methods in de juiste volgorde worden uitgevoerd zodat de
   juiste informatie wordt verkregen.'''    
def main():  
    gegevensHuisartsZoeken()
    listMakenNaam()
    praktijkZoeken()
    praktijkVullen()
    prSamenvoegen(prNr, prNa1, prNa2)
    praktijkSort(pr)
    kolomSamenvoegen()
    bestandInlezen()
    nummersSplitsen()
    haEnPr(kopHa, kopPr)
    kopSort(kopHaPr)
    koppeling(koppelSort, prSort, haData)
    databaseInvullen()

if __name__ == "__main__":
    main()